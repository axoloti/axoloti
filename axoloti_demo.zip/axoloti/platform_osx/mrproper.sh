#!/bin/bash
rm -rv i386/lib/
rm -rv i386/share/
rm -rv i386/bin/
rm -rv i386/include/
rm -rv x86_64/lib/
rm -rv x86_64/share/
rm -rv x86_64/bin/
rm -rv x86_64/include/
rm -rv bin/
rm -rv lib/
