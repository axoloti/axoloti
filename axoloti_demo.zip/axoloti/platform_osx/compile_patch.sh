#!/bin/sh
echo "no binary tools in this demo"
