#!/bin/bash
echo "no binary tools in this demo"
