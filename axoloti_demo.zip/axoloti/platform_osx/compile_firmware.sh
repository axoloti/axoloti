#!/bin/sh
echo "this is a demo distribution, compiler not included"
