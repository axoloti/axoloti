Axoloti
=======
Axoloti is a platform for sketching music-DSP algorithms running on standalone hardware.
www.axoloti.be

by Johannes Taelman
johannes.taelman@gmail.com

Launching Axoloti
requires Java runtime.
* on OSX: doubleclick Axoloti.command
* on Windows: doubleclick Axoloti.bat
* on Linux: doubleclick Axoloti.sh

documentation: in the folder doc/
